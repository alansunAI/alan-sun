"use client";
import { useState } from "react";

const contactEmail = process.env.NEXT_PUBLIC_CONTACT_EMAIL || "bergamaschialan@gmail.com";
const useServerless = (process.env.NEXT_PUBLIC_USE_SERVERLESS || "false") === "true";
const serverlessEndpoint = process.env.NEXT_PUBLIC_SERVERLESS_ENDPOINT || "/api/openai-proxy";

export default function DemoChat(){
  const [messages, setMessages] = useState([{ who:'a', text:'Ciao! Chiedimi qualcosa… ✨' }]);
  const [q, setQ] = useState("");
  const add = (who, text) => setMessages(prev => [...prev, {who, text}]);

  const fakeAI = (prompt) => {
    const p = prompt.trim();
    if (!p) return "Dimmi pure cosa ti serve 😉";
    if (/instagram|post/i.test(p)) return `Ecco un post rapido:\n\n"${p.replace(/\.$/,'')} — Provalo oggi! ☀️ #AlanSun"`;
    const words = p.split(/\s+/);
    if (words.length < 6) return `Certo! Dimmi più dettagli su: “${p}”.`;
    return `Riassunto in 1 frase: ${p.slice(0, 160)}${p.length>160?'…':''}`;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const msg = q; setQ("");
    add('a', msg);
    add('b', 'Sto pensando…');
    try{
      let reply;
      if(useServerless){
        const r = await fetch(serverlessEndpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ messages: [{ role:'user', content: msg }] }) });
        const data = await r.json();
        reply = data.reply || 'Risposta ricevuta.';
      }else{
        reply = fakeAI(msg);
      }
      setMessages(prev => prev.slice(0,-1).concat({who:'b', text:reply}));
    }catch(e){
      setMessages(prev => prev.slice(0,-1).concat({who:'b', text:'Ops! Non riesco a rispondere ora.'}));
    }
  };

  return (
    <div className="demo-wrap">
      <div className="chat" aria-live="polite">
        {messages.map((m,i)=> <div key={i} className={"bubble " + m.who}>{m.text}</div>)}
      </div>
      <form className="chat-input" onSubmit={onSubmit}>
        <label className="sr-only" htmlFor="userMessage">Messaggio</label>
        <input id="userMessage" value={q} onChange={e=>setQ(e.target.value)} placeholder="Es: Scrivi un post Instagram sul gelato alla stracciatella" required />
        <button className="btn btn-primary" type="submit">Invia</button>
      </form>
      <p className="hint">Suggerimento: questa demo funziona {useServerless ? "con l'AI reale" : "in locale"}. Per attivare l'AI reale imposta le variabili d'ambiente su Vercel.</p>
      <p className="hint">Contatti: <a href={`mailto:${contactEmail}`}>{contactEmail}</a></p>
    </div>
  );
}
