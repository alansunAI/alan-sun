"use client";
import { useEffect, useState } from "react";

export default function Header(){
  const [shadow, setShadow] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setShadow(window.scrollY > 4);
    window.addEventListener("scroll", onScroll);
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className="site-header" data-shadow={shadow?'true':'false'}>
      <div className="container nav">
        <a href="#home" className="brand" aria-label="Home Alan Sun">
          <img src="/logo.svg" alt="Logo Alan Sun" width="36" height="36" />
          <span className="brand-text">Alan <strong>Sun</strong></span>
        </a>
        <nav className="nav-links" aria-label="Principale">
          <a href="#funzioni">Funzioni</a>
          <a href="#demo">Demo</a>
          <a href="#prezzi">Prezzi</a>
          <a href="#faq">FAQ</a>
          <a href="#contatti">Contatti</a>
        </nav>
        <button className="nav-toggle" aria-expanded={open} aria-controls="menu-mobile" aria-label="Apri menu" onClick={()=>setOpen(!open)}>
          <span></span><span></span><span></span>
        </button>
      </div>
      <div id="menu-mobile" className={"menu-mobile" + (open ? " show" : "")} hidden={!open}>
        <a href="#funzioni" onClick={()=>setOpen(false)}>Funzioni</a>
        <a href="#demo" onClick={()=>setOpen(false)}>Demo</a>
        <a href="#prezzi" onClick={()=>setOpen(false)}>Prezzi</a>
        <a href="#faq" onClick={()=>setOpen(false)}>FAQ</a>
        <a href="#contatti" onClick={()=>setOpen(false)}>Contatti</a>
      </div>
    </header>
  );
}
