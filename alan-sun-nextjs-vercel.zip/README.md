# Alan Sun — Starter (Next.js + Tailwind) per Vercel

## Avvio locale
1. `npm install`
2. `npm run dev`

## Variabili ambiente (Vercel)
- `OPENAI_API_KEY` (Server) — **obbligatoria** per attivare l'AI reale.
- `NEXT_PUBLIC_CONTACT_EMAIL` (Client) — default: `bergamaschialan@gmail.com`.
- `NEXT_PUBLIC_WHATSAPP` (Client) — es: `https://wa.me/41790000000`.
- `NEXT_PUBLIC_USE_SERVERLESS` (Client) — `true` per usare l'endpoint /api/openai-proxy.
- `NEXT_PUBLIC_SERVERLESS_ENDPOINT` (Client) — default: `/api/openai-proxy`.

Dopo il deploy su Vercel, abilita `NEXT_PUBLIC_USE_SERVERLESS=true` per risposte reali.

## Deploy su Vercel
Importa il repo da GitHub su Vercel e clicca **Deploy**.
