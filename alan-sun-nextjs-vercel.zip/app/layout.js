import "./globals.css";

export const metadata = {
  title: "Alan Sun — L'AI che lavora per te",
  description: "Scrivi, crea immagini, invia email, risolvi esercizi: la tua AI in arancione.",
  themeColor: "#ff7a00",
  openGraph: {
    title: "Alan Sun — L'AI che lavora per te",
    description: "Scrivi, crea immagini, invia email, risolvi esercizi. Tutto in un sito velocissimo.",
    type: "website",
    images: ["/og-cover.png"]
  },
  icons: { icon: "/favicon.svg" }
};

export default function RootLayout({ children }) {
  return (
    <html lang="it">
      <body>{children}</body>
    </html>
  );
}
