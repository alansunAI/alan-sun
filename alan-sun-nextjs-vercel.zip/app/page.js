import Header from "../components/Header";
import DemoChat from "../components/DemoChat";

export default function Home() {
  return (
    <main id="contenuto">
      <a className="skip-link" href="#contenuto">Salta al contenuto</a>
      <Header />
      <section id="home" className="hero container">
        <div className="hero-text">
          <h1>Alan Sun <span className="badge">beta</span></h1>
          <p className="lead">La tua AI tuttofare in <b>bianchi e arancioni</b>: testi, immagini, email e soluzioni—subito.</p>
          <div className="cta-group">
            <a className="btn btn-primary" href="#demo">Prova la demo</a>
            <a className="btn btn-ghost" href="#prezzi">Vedi i prezzi</a>
          </div>
          <ul className="hero-points">
            <li>✔️ Interfaccia pulita e veloce</li>
            <li>✔️ Pronta per la pubblicità e i social</li>
            <li>✔️ Struttura SEO-friendly</li>
          </ul>
        </div>
        <div className="hero-art">
          <img src="/hero-illustration.svg" alt="Illustrazione: sole stilizzato arancione" />
        </div>
      </section>

      <section id="funzioni" className="container section">
        <h2>Funzioni principali</h2>
        <div className="grid features">
          <article className="card">
            <h3>Generazione testi</h3>
            <p>Post, email, descrizioni: scrivi meglio e più veloce.</p>
          </article>
          <article className="card">
            <h3>Immagini</h3>
            <p>Crea immagini d'impatto per social e annunci.</p>
          </article>
          <article className="card">
            <h3>Email & Customer Care</h3>
            <p>Bozze in un click, tono personalizzato.</p>
          </article>
          <article className="card">
            <h3>Esercizi & studio</h3>
            <p>Spiegazioni passo-passo (con responsabilità).</p>
          </article>
        </div>
      </section>

      <section id="demo" className="container section">
        <h2>Demo veloce</h2>
        <DemoChat />
      </section>

      <section id="prezzi" className="container section">
        <h2>Prezzi</h2>
        <div className="grid pricing">
          <article className="card price">
            <h3>Gratuito</h3>
            <p className="euro">0 €</p>
            <ul>
              <li>Demo locale</li>
              <li>Accesso al sito</li>
              <li>FAQ & guide</li>
            </ul>
            <a className="btn btn-ghost" href="#contatti">Inizia</a>
          </article>
          <article className="card price highlight">
            <div className="ribbon">Più scelto</div>
            <h3>Pro</h3>
            <p className="euro">19 € / mese</p>
            <ul>
              <li>AI reale (proxy sicuro)</li>
              <li>Export contenuti</li>
              <li>Assistenza prioritaria</li>
            </ul>
            <a className="btn btn-primary" href="#contatti">Attiva</a>
          </article>
          <article className="card price">
            <h3>Business</h3>
            <p className="euro">49 € / mese</p>
            <ul>
              <li>Team & ruoli</li>
              <li>Limiti elevati</li>
              <li>Fatturazione</li>
            </ul>
            <a className="btn btn-ghost" href="#contatti">Parla con noi</a>
          </article>
        </div>
        <details id="ai-reale" className="note">
          <summary>Come attivare l'AI reale in sicurezza</summary>
          <ol>
            <li>Imposta la variabile <code>NEXT_PUBLIC_USE_SERVERLESS=true</code> su Vercel.</li>
            <li>Usa l'endpoint <code>/api/openai-proxy</code> già incluso.</li>
            <li>Imposta <code>OPENAI_API_KEY</code> come variabile ambiente (server only).</li>
          </ol>
        </details>
      </section>

      <section id="faq" className="container section">
        <h2>FAQ</h2>
        <div className="faq">
          <details>
            <summary>Posso usare subito la demo?</summary>
            <p>Sì, funziona direttamente nel browser senza chiavi o server.</p>
          </details>
          <details>
            <summary>L'AI reale è compresa?</summary>
            <p>È supportata via proxy serverless: evita di mettere la chiave API nel frontend.</p>
          </details>
          <details>
            <summary>Posso personalizzare colori e logo?</summary>
            <p>Certo! Tutto il tema è gestito da variabili CSS in <code>app/globals.css</code>.</p>
          </details>
        </div>
      </section>

      <section id="contatti" className="container section">
        <h2>Contatti</h2>
        <div className="grid contact">
          <form id="contactForm" className="card form-card" onSubmit={(e)=>{e.preventDefault(); window.location.href=`mailto:${process.env.NEXT_PUBLIC_CONTACT_EMAIL||'info@example.com'}`;}}>
            <label>Nome<input required name="name" placeholder="Il tuo nome"/></label>
            <label>Email<input required type="email" name="email" placeholder="tu@esempio.com"/></label>
            <label>Messaggio<textarea required name="message" rows="4" placeholder="Scrivi qui…"></textarea></label>
            <button className="btn btn-primary" type="submit">Invia</button>
            <p className="form-status" aria-live="polite"></p>
          </form>
          <div className="card">
            <h3>Parliamone</h3>
            <p>Email: <a href={`mailto:${process.env.NEXT_PUBLIC_CONTACT_EMAIL||'bergamaschialan@gmail.com'}`}>{process.env.NEXT_PUBLIC_CONTACT_EMAIL||'bergamaschialan@gmail.com'}</a></p>
            <p>WhatsApp: <a href={process.env.NEXT_PUBLIC_WHATSAPP||'#'} rel="noopener">Chatta su WA</a></p>
            <p>Oppure usa il form qui accanto.</p>
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <div className="container footer-grid">
          <div className="brand-spot">
            <img src="/logo.svg" alt="Logo Alan Sun" width="28" height="28" />
            <span>Alan Sun</span>
          </div>
          <nav aria-label="Footer">
            <a href="#privacy">Privacy</a>
            <a href="#termini">Termini</a>
          </nav>
          <p className="copy">© {new Date().getFullYear()} Alan Sun — Tutti i diritti riservati.</p>
        </div>
      </footer>
    </main>
  );
}
